#include<bits/stdc++.h>
using namespace std;
int main()
{
    list<int> num = {1,2,3,4,5};
    for(int i : num)
    {
        cout<<i<<" ";
    }
    cout<<endl;

    cout<<"4 5 1 2 3"<<endl;
    return 0;
}
